# Pro Surf — Dark Immersive Guidelines

## Aesthetic Stance: Dark Immersive

Full commitment to edge-to-edge darkness. The interface recedes entirely so surf media dominates every surface.

## Color Tokens

| Token | Value | Use |
|---|---|---|
| Background | `#0A0A0B` | Page ground, nav |
| Foreground | `#F0EDEA` | Primary text |
| Muted | `#6B6866` | Labels, timestamps, captions |
| Border | `rgba(255,255,255,0.08)` | Hairline dividers |
| Accent / Live | `#B3241F` | Live badges, active tab, CTAs |
| Card | `rgba(255,255,255,0.04)` | Subtle surface lift |

## Typography

- **Display / headings:** DM Sans 600–700, tracking -0.02em
- **Body / UI:** DM Sans 400–500, comfortable line-height 1.55
- No condensed, no all-caps blocks, no italic display

## Spacing & Shape

- 0–4px radii on cards; 0px on full-bleed imagery
- 8px base unit, multiples of 8 for all spacing
- Bottom nav height: 64px + safe-area inset

## Imagery

Unsplash surf photography — full-bleed, 0px radius, dark scrim overlays at 40–60% opacity for legibility. Images always carry a `bg-[#0A0A0B]` fallback.

## Rules

- No glow, no neon, no multicolor gradients
- No condensed all-caps type, no horizontal ticker bands
- Controls surface on interaction (hover/focus), recede otherwise
- One accent color only: deep red `#B3241F` for live, active, and primary actions
