import { useState } from 'react'

// ─── Icons (inline SVG, minimal stroke style) ─────────────────────────────────
const Icon = {
  Home: () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 9.5L12 3l9 6.5V20a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9.5z"/>
      <polyline points="9 21 9 12 15 12 15 21"/>
    </svg>
  ),
  News: () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/>
      <line x1="9" y1="21" x2="9" y2="9"/>
    </svg>
  ),
  Shop: () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/>
      <path d="M16 10a4 4 0 0 1-8 0"/>
    </svg>
  ),
  Wave: () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 12c1.5-3 3-4.5 4.5-4.5S9 9 10.5 9s3-1.5 4.5-1.5S18 9 19.5 9 21 7.5 22 7.5"/>
      <path d="M2 17c1.5-3 3-4.5 4.5-4.5S9 14 10.5 14s3-1.5 4.5-1.5S18 14 19.5 14 21 12.5 22 12.5"/>
    </svg>
  ),
  Live: () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <polygon points="5 3 19 12 5 21 5 3"/>
    </svg>
  ),
  Friends: () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>
      <path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
    </svg>
  ),
  Camera: () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
      <circle cx="12" cy="13" r="4"/>
    </svg>
  ),
  Docs: () => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/>
      <line x1="12" y1="16" x2="12.01" y2="16"/>
    </svg>
  ),
  Bell: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>
    </svg>
  ),
  Search: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
    </svg>
  ),
  Heart: () => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
    </svg>
  ),
  Comment: () => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
    </svg>
  ),
  Share: () => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
      <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
    </svg>
  ),
  Wind: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9.59 4.59A2 2 0 1 1 11 8H2m10.59 11.41A2 2 0 1 0 14 16H2m15.73-8.27A2.5 2.5 0 1 1 19.5 12H2"/>
    </svg>
  ),
  Trophy: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="8 21 12 17 16 21"/><line x1="12" y1="17" x2="12" y2="11"/>
      <path d="M7 4H4a1 1 0 0 0-1 1v2a5 5 0 0 0 5 5 5 5 0 0 0 5-5v-1M17 4h3a1 1 0 0 1 1 1v2a5 5 0 0 1-5 5 5 5 0 0 1-5-5v-1"/>
      <rect x="7" y="2" width="10" height="9" rx="1"/>
    </svg>
  ),
  Plus: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
    </svg>
  ),
  Cart: () => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/>
      <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
    </svg>
  ),
  Thermometer: () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 14.76V3.5a2.5 2.5 0 0 0-5 0v11.26a4.5 4.5 0 1 0 5 0z"/>
    </svg>
  ),
  Star: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" stroke="none">
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
    </svg>
  ),
  UserPlus: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/>
      <line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/>
    </svg>
  ),
}

// ─── Types ────────────────────────────────────────────────────────────────────
type Tab = 'feed' | 'news' | 'shop' | 'weather' | 'live' | 'friends' | 'media' | 'docs'

// ─── Data ─────────────────────────────────────────────────────────────────────
const feedPosts = [
  {
    id: 1,
    user: 'Gabriel Medina',
    handle: '@medina',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=80&h=80&fit=crop&auto=format',
    time: '12 min',
    image: 'https://images.unsplash.com/photo-1502680390469-be75c86b636f?w=800&h=500&fit=crop&auto=format',
    caption: 'Perfect barrels at Teahupoo this morning. Swell holding at 8–10ft. 🤙',
    likes: 4821,
    comments: 312,
  },
  {
    id: 2,
    user: 'Carissa Moore',
    handle: '@carissa',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=80&h=80&fit=crop&auto=format',
    time: '1 h',
    image: 'https://images.unsplash.com/photo-1455729552865-3658a5d39692?w=800&h=500&fit=crop&auto=format',
    caption: 'Morning session at Pipeline. Water temp 27 °C, glassy conditions. Back to finals!',
    likes: 3204,
    comments: 198,
  },
  {
    id: 3,
    user: 'Italo Ferreira',
    handle: '@italoferreira',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=80&h=80&fit=crop&auto=format',
    time: '3 h',
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop&auto=format',
    caption: 'Training for the Tahiti Pro. This wave is a different planet. 🌊',
    likes: 6110,
    comments: 440,
  },
]

const newsItems = [
  {
    id: 1,
    tag: 'CAMPEONATO',
    title: 'Medina avança para as semifinais do Tahiti Pro com nota perfeita 10',
    time: '2 h atrás',
    image: 'https://images.unsplash.com/photo-1502680390469-be75c86b636f?w=600&h=380&fit=crop&auto=format',
    readTime: '4 min',
  },
  {
    id: 2,
    tag: 'EQUIPAMENTO',
    title: 'Rip Curl lança wetsuit 2026 com tecnologia de temperatura adaptativa',
    time: '5 h atrás',
    image: 'https://images.unsplash.com/photo-1519451241324-20b4ea2c4220?w=600&h=380&fit=crop&auto=format',
    readTime: '3 min',
  },
  {
    id: 3,
    tag: 'DESTINO',
    title: 'As 10 melhores ondas do mundo para surfar em outubro de 2026',
    time: '1 dia atrás',
    image: 'https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?w=600&h=380&fit=crop&auto=format',
    readTime: '7 min',
  },
  {
    id: 4,
    tag: 'SAÚDE',
    title: 'Rotina de alongamento dos surfistas profissionais do CT',
    time: '2 dias atrás',
    image: 'https://images.unsplash.com/photo-1530549387789-4c1017266635?w=600&h=380&fit=crop&auto=format',
    readTime: '5 min',
  },
]

const products = [
  {
    id: 1,
    name: 'Prancha Shortboard 6\'2"',
    brand: 'Channel Islands',
    price: 'R$ 3.490',
    rating: 4.8,
    reviews: 142,
    image: 'https://images.unsplash.com/photo-1455729552865-3658a5d39692?w=400&h=400&fit=crop&auto=format',
  },
  {
    id: 2,
    name: 'Wetsuit Flash Bomb 3/2',
    brand: 'Rip Curl',
    price: 'R$ 1.890',
    rating: 4.9,
    reviews: 87,
    image: 'https://images.unsplash.com/photo-1519451241324-20b4ea2c4220?w=400&h=400&fit=crop&auto=format',
  },
  {
    id: 3,
    name: 'Leash Pro 9mm 7\'',
    brand: 'Dakine',
    price: 'R$ 189',
    rating: 4.7,
    reviews: 310,
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=400&h=400&fit=crop&auto=format',
  },
  {
    id: 4,
    name: 'Parafina Tropical',
    brand: 'Sex Wax',
    price: 'R$ 32',
    rating: 5.0,
    reviews: 2104,
    image: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=400&h=400&fit=crop&auto=format',
  },
]

const heats = [
  {
    id: 1,
    event: 'Tahiti Pro — Chanel Islands',
    round: 'Semifinal 1',
    live: true,
    surfer1: { name: 'G. Medina', country: '🇧🇷', score: 17.43 },
    surfer2: { name: 'J. Florence', country: '🇺🇸', score: 15.90 },
    timeLeft: '14:22',
    waveHeight: '8–10 ft',
  },
  {
    id: 2,
    event: 'Tahiti Pro — Chanel Islands',
    round: 'Semifinal 2',
    live: true,
    surfer1: { name: 'I. Ferreira', country: '🇧🇷', score: 13.75 },
    surfer2: { name: 'F. Toledo', country: '🇧🇷', score: 14.30 },
    timeLeft: '22:08',
    waveHeight: '8–10 ft',
  },
  {
    id: 3,
    event: 'Margaret River Pro',
    round: 'Quartas de Final',
    live: false,
    surfer1: { name: 'C. Moore', country: '🇺🇸', score: 16.20 },
    surfer2: { name: 'T. Smith', country: '🇿🇦', score: 12.55 },
    timeLeft: '—',
    waveHeight: '5–7 ft',
  },
]

const weatherSpots = [
  {
    id: 1,
    name: 'Teahupoo',
    location: 'Tahiti, PF',
    image: 'https://images.unsplash.com/photo-1502680390469-be75c86b636f?w=600&h=300&fit=crop&auto=format',
    temp: '27 °C',
    wind: '12 kn NE',
    wave: '8–10 ft',
    quality: 'ÉPICO',
    qualityColor: '#B3241F',
    period: '16 s',
    tide: 'Enchendo',
  },
  {
    id: 2,
    name: 'Pipeline',
    location: 'Oahu, HI',
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&h=300&fit=crop&auto=format',
    temp: '26 °C',
    wind: '8 kn E',
    wave: '5–7 ft',
    quality: 'BOM',
    qualityColor: '#4A9E6A',
    period: '13 s',
    tide: 'Vazante',
  },
  {
    id: 3,
    name: 'Saquarema',
    location: 'RJ, Brasil',
    image: 'https://images.unsplash.com/photo-1455729552865-3658a5d39692?w=600&h=300&fit=crop&auto=format',
    temp: '24 °C',
    wind: '18 kn S',
    wave: '3–5 ft',
    quality: 'REGULAR',
    qualityColor: '#C48A2A',
    period: '10 s',
    tide: 'Cheia',
  },
]

const friends = [
  { id: 1, name: 'Lucas Chumbo', handle: '@chumbo', status: 'online', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&h=80&fit=crop&auto=format', mutual: 14, surfing: true },
  { id: 2, name: 'Tatiana Weston-Webb', handle: '@tati', status: 'online', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80&h=80&fit=crop&auto=format', mutual: 8, surfing: false },
  { id: 3, name: 'Yago Dora', handle: '@yago', status: 'offline', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop&auto=format', mutual: 22, surfing: false },
  { id: 4, name: 'Silvana Lima', handle: '@silvanalima', status: 'online', avatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=80&h=80&fit=crop&auto=format', mutual: 5, surfing: true },
  { id: 5, name: 'Adriano de Souza', handle: '@mineirinho', status: 'offline', avatar: 'https://images.unsplash.com/photo-1552058544-f2b08422138a?w=80&h=80&fit=crop&auto=format', mutual: 31, surfing: false },
  { id: 6, name: 'Lakey Peterson', handle: '@lakey', status: 'online', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=80&h=80&fit=crop&auto=format', mutual: 9, surfing: false },
]

const mediaItems = [
  { id: 1, type: 'photo', url: 'https://images.unsplash.com/photo-1502680390469-be75c86b636f?w=400&h=400&fit=crop&auto=format', user: 'medina', likes: 4821 },
  { id: 2, type: 'video', url: 'https://images.unsplash.com/photo-1455729552865-3658a5d39692?w=400&h=400&fit=crop&auto=format', user: 'carissa', likes: 3204, duration: '0:47' },
  { id: 3, type: 'photo', url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=400&h=400&fit=crop&auto=format', user: 'italoferreira', likes: 6110 },
  { id: 4, type: 'video', url: 'https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?w=400&h=400&fit=crop&auto=format', user: 'chumbo', likes: 2980, duration: '1:24' },
  { id: 5, type: 'photo', url: 'https://images.unsplash.com/photo-1530549387789-4c1017266635?w=400&h=400&fit=crop&auto=format', user: 'tati', likes: 1740 },
  { id: 6, type: 'photo', url: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&h=400&fit=crop&auto=format', user: 'yago', likes: 890 },
  { id: 7, type: 'video', url: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=400&h=400&fit=crop&auto=format', user: 'silvanalima', likes: 3320, duration: '2:10' },
  { id: 8, type: 'photo', url: 'https://images.unsplash.com/photo-1519451241324-20b4ea2c4220?w=400&h=400&fit=crop&auto=format', user: 'lakey', likes: 2201 },
  { id: 9, type: 'photo', url: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=400&fit=crop&auto=format', user: 'mineirinho', likes: 1567 },
]

// ─── Sub-components ───────────────────────────────────────────────────────────

function LiveBadge() {
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-600 tracking-wide"
      style={{ backgroundColor: '#B3241F', color: '#F0EDEA' }}>
      <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse inline-block" />
      AO VIVO
    </span>
  )
}

function Avatar({ src, size = 40, online = false }: { src: string; size?: number; online?: boolean }) {
  return (
    <div className="relative flex-shrink-0" style={{ width: size, height: size }}>
      <img src={src} alt="" width={size} height={size}
        className="rounded-full object-cover"
        style={{ width: size, height: size, backgroundColor: '#1a1a1b' }} />
      {online && (
        <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-[#0A0A0B]"
          style={{ backgroundColor: '#4A9E6A' }} />
      )}
    </div>
  )
}

// ─── Tab Views ─────────────────────────────────────────────────────────────────

function FeedTab() {
  const [liked, setLiked] = useState<Set<number>>(new Set())
  return (
    <div className="flex flex-col gap-0">
      {feedPosts.map(post => (
        <article key={post.id} className="border-b" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
          {/* Author */}
          <div className="flex items-center gap-3 px-4 py-3">
            <Avatar src={post.avatar} size={38} online />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-600 leading-none" style={{ color: '#F0EDEA' }}>{post.user}</p>
              <p className="text-xs mt-0.5" style={{ color: '#6B6866' }}>{post.handle} · {post.time}</p>
            </div>
          </div>
          {/* Image — full bleed */}
          <div className="w-full aspect-[4/3] overflow-hidden" style={{ backgroundColor: '#111' }}>
            <img src={post.image} alt={post.caption} className="w-full h-full object-cover" />
          </div>
          {/* Actions */}
          <div className="flex items-center gap-5 px-4 py-3">
            <button onClick={() => setLiked(prev => { const s = new Set(prev); s.has(post.id) ? s.delete(post.id) : s.add(post.id); return s })}
              className="flex items-center gap-1.5 transition-opacity hover:opacity-70"
              style={{ color: liked.has(post.id) ? '#B3241F' : '#6B6866' }}>
              <Icon.Heart />
              <span className="text-xs">{(post.likes + (liked.has(post.id) ? 1 : 0)).toLocaleString('pt-BR')}</span>
            </button>
            <button className="flex items-center gap-1.5 hover:opacity-70 transition-opacity" style={{ color: '#6B6866' }}>
              <Icon.Comment />
              <span className="text-xs">{post.comments}</span>
            </button>
            <button className="flex items-center gap-1.5 hover:opacity-70 transition-opacity ml-auto" style={{ color: '#6B6866' }}>
              <Icon.Share />
            </button>
          </div>
          {/* Caption */}
          <p className="px-4 pb-4 text-sm leading-relaxed" style={{ color: '#F0EDEA' }}>
            <span className="font-600">{post.user} </span>{post.caption}
          </p>
        </article>
      ))}
    </div>
  )
}

function NewsTab() {
  const tags: Record<string, string> = { CAMPEONATO: '#B3241F', EQUIPAMENTO: '#4A9E6A', DESTINO: '#3B6FD4', SAÚDE: '#C48A2A' }
  return (
    <div className="flex flex-col">
      {/* Featured */}
      <div className="relative w-full aspect-[16/9] overflow-hidden" style={{ backgroundColor: '#111' }}>
        <img src={newsItems[0].image} alt={newsItems[0].title} className="w-full h-full object-cover" />
        <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(10,10,11,0.92) 0%, transparent 60%)' }} />
        <div className="absolute bottom-0 left-0 right-0 p-5">
          <span className="text-xs font-700 tracking-wider px-2 py-0.5 rounded"
            style={{ backgroundColor: tags[newsItems[0].tag] || '#B3241F', color: '#fff' }}>
            {newsItems[0].tag}
          </span>
          <h2 className="mt-2 text-lg font-700 leading-tight" style={{ color: '#F0EDEA' }}>{newsItems[0].title}</h2>
          <p className="text-xs mt-1" style={{ color: '#6B6866' }}>{newsItems[0].time} · {newsItems[0].readTime} de leitura</p>
        </div>
      </div>
      {/* List */}
      <div className="divide-y" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
        {newsItems.slice(1).map(item => (
          <div key={item.id} className="flex gap-3 p-4 cursor-pointer hover:bg-white/[0.02] transition-colors">
            <div className="flex-1 min-w-0">
              <span className="text-xs font-700 tracking-wider"
                style={{ color: tags[item.tag] || '#B3241F' }}>{item.tag}</span>
              <h3 className="mt-1 text-sm font-500 leading-snug" style={{ color: '#F0EDEA' }}>{item.title}</h3>
              <p className="text-xs mt-1.5" style={{ color: '#6B6866' }}>{item.time} · {item.readTime} de leitura</p>
            </div>
            <div className="w-20 h-20 flex-shrink-0 rounded overflow-hidden" style={{ backgroundColor: '#111' }}>
              <img src={item.image} alt="" className="w-full h-full object-cover" />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function ShopTab() {
  const [cart, setCart] = useState<Set<number>>(new Set())
  return (
    <div className="flex flex-col">
      {/* Search bar */}
      <div className="sticky top-0 px-4 py-3 z-10" style={{ backgroundColor: '#0A0A0B', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
        <div className="flex items-center gap-2 px-3 py-2 rounded" style={{ backgroundColor: 'rgba(255,255,255,0.06)' }}>
          <Icon.Search />
          <span className="text-sm" style={{ color: '#6B6866' }}>Buscar produtos...</span>
        </div>
      </div>
      {/* Categories */}
      <div className="flex gap-2 px-4 py-3 overflow-x-auto">
        {['Todos', 'Pranchas', 'Wetsuits', 'Leashes', 'Parafina', 'Camisas', 'Óculos'].map((cat, i) => (
          <button key={cat} className="flex-shrink-0 px-3 py-1.5 rounded text-xs font-500 transition-all"
            style={i === 0
              ? { backgroundColor: '#B3241F', color: '#fff' }
              : { backgroundColor: 'rgba(255,255,255,0.06)', color: '#6B6866' }}>
            {cat}
          </button>
        ))}
      </div>
      {/* Product grid */}
      <div className="grid grid-cols-2 gap-px" style={{ backgroundColor: 'rgba(255,255,255,0.08)' }}>
        {products.map(p => (
          <div key={p.id} className="flex flex-col" style={{ backgroundColor: '#0A0A0B' }}>
            <div className="aspect-square overflow-hidden" style={{ backgroundColor: '#111' }}>
              <img src={p.image} alt={p.name} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
            </div>
            <div className="p-3 flex flex-col flex-1">
              <p className="text-xs" style={{ color: '#6B6866' }}>{p.brand}</p>
              <p className="text-sm font-500 mt-0.5 leading-tight" style={{ color: '#F0EDEA' }}>{p.name}</p>
              <div className="flex items-center gap-1 mt-1">
                <span style={{ color: '#C48A2A' }}><Icon.Star /></span>
                <span className="text-xs" style={{ color: '#6B6866' }}>{p.rating} ({p.reviews})</span>
              </div>
              <div className="flex items-center justify-between mt-2">
                <span className="text-sm font-700" style={{ color: '#F0EDEA' }}>{p.price}</span>
                <button onClick={() => setCart(prev => { const s = new Set(prev); s.has(p.id) ? s.delete(p.id) : s.add(p.id); return s })}
                  className="p-1.5 rounded transition-all"
                  style={{ backgroundColor: cart.has(p.id) ? '#B3241F' : 'rgba(255,255,255,0.06)', color: '#F0EDEA' }}>
                  <Icon.Cart />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function WeatherTab() {
  const [selected, setSelected] = useState(0)
  const spot = weatherSpots[selected]
  return (
    <div className="flex flex-col">
      {/* Hero spot */}
      <div className="relative w-full" style={{ height: 260, backgroundColor: '#111' }}>
        <img src={spot.image} alt={spot.name} className="w-full h-full object-cover" style={{ transition: 'opacity 0.3s' }} />
        <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(10,10,11,1) 0%, rgba(10,10,11,0.4) 60%, transparent 100%)' }} />
        <div className="absolute bottom-0 left-0 right-0 p-5">
          <p className="text-xs font-500" style={{ color: '#6B6866' }}>{spot.location}</p>
          <div className="flex items-end justify-between">
            <h2 className="text-2xl font-700 mt-0.5" style={{ color: '#F0EDEA' }}>{spot.name}</h2>
            <span className="text-xs font-700 px-2 py-1 rounded" style={{ backgroundColor: spot.qualityColor + '22', color: spot.qualityColor, border: `1px solid ${spot.qualityColor}44` }}>
              {spot.quality}
            </span>
          </div>
        </div>
      </div>
      {/* Spot selector */}
      <div className="flex gap-2 px-4 py-3 border-b" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
        {weatherSpots.map((s, i) => (
          <button key={s.id} onClick={() => setSelected(i)}
            className="flex-1 py-2 text-xs font-500 rounded transition-all"
            style={selected === i
              ? { backgroundColor: 'rgba(179,36,31,0.15)', color: '#B3241F', border: '1px solid rgba(179,36,31,0.4)' }
              : { backgroundColor: 'rgba(255,255,255,0.04)', color: '#6B6866', border: '1px solid transparent' }}>
            {s.name}
          </button>
        ))}
      </div>
      {/* Metrics grid */}
      <div className="grid grid-cols-3 gap-px m-4" style={{ backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 4 }}>
        {[
          { icon: <Icon.Thermometer />, label: 'Temperatura', value: spot.temp },
          { icon: <Icon.Wind />, label: 'Vento', value: spot.wind },
          { icon: <Icon.Wave />, label: 'Ondas', value: spot.wave },
          { icon: null, label: 'Período', value: spot.period, emoji: '⏱' },
          { icon: null, label: 'Maré', value: spot.tide, emoji: '🌊' },
          { icon: null, label: 'Qualidade', value: spot.quality, emoji: '📊' },
        ].map((m, i) => (
          <div key={i} className="flex flex-col items-center justify-center py-4 px-2" style={{ backgroundColor: '#0A0A0B' }}>
            <span style={{ color: '#6B6866' }}>{m.icon || <span className="text-lg">{m.emoji}</span>}</span>
            <p className="text-xs mt-1" style={{ color: '#6B6866' }}>{m.label}</p>
            <p className="text-sm font-700 mt-0.5" style={{ color: '#F0EDEA' }}>{m.value}</p>
          </div>
        ))}
      </div>
      {/* 5-day forecast strip */}
      <div className="px-4 pb-4">
        <p className="text-xs font-500 mb-2" style={{ color: '#6B6866' }}>PREVISÃO 5 DIAS</p>
        <div className="flex gap-2">
          {['Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map((day, i) => (
            <div key={day} className="flex-1 flex flex-col items-center py-3 rounded"
              style={{ backgroundColor: i === 0 ? 'rgba(179,36,31,0.12)' : 'rgba(255,255,255,0.04)', border: i === 0 ? '1px solid rgba(179,36,31,0.3)' : '1px solid transparent' }}>
              <p className="text-xs font-500" style={{ color: '#6B6866' }}>{day}</p>
              <p className="text-sm font-700 mt-1" style={{ color: '#F0EDEA' }}>{['🌊', '⛅', '🌧', '🌊', '☀️'][i]}</p>
              <p className="text-xs mt-1" style={{ color: '#F0EDEA' }}>{['8ft', '5ft', '3ft', '7ft', '6ft'][i]}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function LiveTab() {
  return (
    <div className="flex flex-col gap-0">
      {/* Event header */}
      <div className="relative w-full overflow-hidden" style={{ height: 180, backgroundColor: '#111' }}>
        <img src="https://images.unsplash.com/photo-1502680390469-be75c86b636f?w=800&h=360&fit=crop&auto=format"
          alt="Tahiti Pro" className="w-full h-full object-cover" />
        <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(10,10,11,1) 0%, rgba(10,10,11,0.3) 70%)' }} />
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <div className="flex items-center gap-2">
            <LiveBadge />
            <span className="text-xs" style={{ color: '#6B6866' }}>WSL Championship Tour 2026</span>
          </div>
          <h2 className="text-lg font-700 mt-1" style={{ color: '#F0EDEA' }}>Tahiti Pro — Teahupoo</h2>
        </div>
      </div>
      {/* Progress bar */}
      <div className="h-0.5 w-full" style={{ backgroundColor: 'rgba(255,255,255,0.08)' }}>
        <div className="h-full progress-bar" style={{ width: '62%' }} />
      </div>
      {/* Heats */}
      <div className="divide-y" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
        {heats.map(heat => (
          <div key={heat.id} className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                {heat.live ? <LiveBadge /> : <span className="text-xs px-2 py-0.5 rounded" style={{ backgroundColor: 'rgba(255,255,255,0.06)', color: '#6B6866' }}>ENCERRADO</span>}
                <span className="text-xs" style={{ color: '#6B6866' }}>{heat.round}</span>
              </div>
              <div className="flex items-center gap-1 text-xs" style={{ color: '#6B6866' }}>
                <Icon.Wave />
                <span>{heat.waveHeight}</span>
              </div>
            </div>
            {/* Scoreboard */}
            <div className="flex items-center gap-2">
              {/* Surfer 1 */}
              <div className="flex-1 flex flex-col items-center py-3 rounded" style={{ backgroundColor: 'rgba(255,255,255,0.04)' }}>
                <span className="text-lg">{heat.surfer1.country}</span>
                <p className="text-sm font-700 mt-1" style={{ color: '#F0EDEA' }}>{heat.surfer1.name}</p>
                <p className="text-xl font-700 mt-1" style={{ color: heat.surfer1.score > heat.surfer2.score ? '#B3241F' : '#F0EDEA' }}>
                  {heat.surfer1.score.toFixed(2)}
                </p>
              </div>
              <div className="text-xs font-700" style={{ color: '#6B6866' }}>VS</div>
              {/* Surfer 2 */}
              <div className="flex-1 flex flex-col items-center py-3 rounded" style={{ backgroundColor: 'rgba(255,255,255,0.04)' }}>
                <span className="text-lg">{heat.surfer2.country}</span>
                <p className="text-sm font-700 mt-1" style={{ color: '#F0EDEA' }}>{heat.surfer2.name}</p>
                <p className="text-xl font-700 mt-1" style={{ color: heat.surfer2.score > heat.surfer1.score ? '#B3241F' : '#F0EDEA' }}>
                  {heat.surfer2.score.toFixed(2)}
                </p>
              </div>
            </div>
            {heat.live && (
              <p className="text-center text-xs mt-2" style={{ color: '#6B6866' }}>
                Tempo restante: <span style={{ color: '#F0EDEA' }}>{heat.timeLeft}</span>
              </p>
            )}
          </div>
        ))}
      </div>
      {/* CT Standings preview */}
      <div className="p-4 border-t" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
        <p className="text-xs font-500 mb-3" style={{ color: '#6B6866' }}>RANKING CT 2026</p>
        {[
          { pos: 1, name: 'G. Medina', pts: 54200, country: '🇧🇷' },
          { pos: 2, name: 'J. Florence', pts: 49800, country: '🇺🇸' },
          { pos: 3, name: 'I. Ferreira', pts: 47100, country: '🇧🇷' },
        ].map(r => (
          <div key={r.pos} className="flex items-center gap-3 py-2">
            <span className="text-sm font-700 w-5 text-right" style={{ color: r.pos === 1 ? '#B3241F' : '#6B6866' }}>{r.pos}</span>
            <span>{r.country}</span>
            <span className="flex-1 text-sm font-500" style={{ color: '#F0EDEA' }}>{r.name}</span>
            <span className="text-xs tabular-nums" style={{ color: '#6B6866' }}>{r.pts.toLocaleString('pt-BR')} pts</span>
          </div>
        ))}
      </div>
    </div>
  )
}

function FriendsTab() {
  return (
    <div className="flex flex-col">
      {/* Search */}
      <div className="px-4 py-3 border-b" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
        <div className="flex items-center gap-2 px-3 py-2 rounded" style={{ backgroundColor: 'rgba(255,255,255,0.06)' }}>
          <Icon.Search />
          <span className="text-sm" style={{ color: '#6B6866' }}>Buscar amigos...</span>
        </div>
      </div>
      {/* Online now */}
      <div className="px-4 pt-4 pb-2">
        <p className="text-xs font-500 mb-3" style={{ color: '#6B6866' }}>SURFANDO AGORA</p>
        <div className="flex gap-4 overflow-x-auto pb-2">
          {friends.filter(f => f.surfing).map(f => (
            <div key={f.id} className="flex flex-col items-center gap-1.5 flex-shrink-0">
              <div className="relative">
                <div className="w-14 h-14 rounded-full p-0.5" style={{ background: 'linear-gradient(135deg, #B3241F, #E06050)' }}>
                  <img src={f.avatar} alt={f.name} className="w-full h-full rounded-full object-cover" style={{ backgroundColor: '#111' }} />
                </div>
              </div>
              <p className="text-xs font-500 text-center w-16 truncate" style={{ color: '#F0EDEA' }}>{f.name.split(' ')[0]}</p>
            </div>
          ))}
        </div>
      </div>
      {/* All friends */}
      <div className="px-4 pt-2">
        <p className="text-xs font-500 mb-3" style={{ color: '#6B6866' }}>TODOS ({friends.length})</p>
        <div className="divide-y" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
          {friends.map(f => (
            <div key={f.id} className="flex items-center gap-3 py-3">
              <Avatar src={f.avatar} size={44} online={f.status === 'online'} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-600" style={{ color: '#F0EDEA' }}>{f.name}</p>
                <p className="text-xs mt-0.5" style={{ color: '#6B6866' }}>{f.handle} · {f.mutual} amigos em comum</p>
                {f.surfing && <span className="text-xs" style={{ color: '#4A9E6A' }}>🌊 Surfando agora</span>}
              </div>
              <button className="px-3 py-1.5 rounded text-xs font-500 transition-all hover:bg-white/[0.08]"
                style={{ backgroundColor: 'rgba(255,255,255,0.06)', color: '#F0EDEA' }}>
                Mensagem
              </button>
            </div>
          ))}
        </div>
      </div>
      {/* Sugestões */}
      <div className="px-4 py-4 border-t mt-2" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
        <p className="text-xs font-500 mb-3" style={{ color: '#6B6866' }}>SUGESTÕES PARA VOCÊ</p>
        <div className="flex items-center gap-3 py-2">
          <Avatar src="https://images.unsplash.com/photo-1463453091185-61582044d556?w=80&h=80&fit=crop&auto=format" size={44} />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-600" style={{ color: '#F0EDEA' }}>Felipe Toledo</p>
            <p className="text-xs mt-0.5" style={{ color: '#6B6866' }}>@felipetoledo · 48 amigos em comum</p>
          </div>
          <button className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-500 transition-all"
            style={{ backgroundColor: 'rgba(179,36,31,0.15)', color: '#B3241F', border: '1px solid rgba(179,36,31,0.3)' }}>
            <Icon.UserPlus /><span>Seguir</span>
          </button>
        </div>
      </div>
    </div>
  )
}

function MediaTab() {
  const [filter, setFilter] = useState<'todos' | 'fotos' | 'videos'>('todos')
  const filtered = mediaItems.filter(m => filter === 'todos' || (filter === 'fotos' && m.type === 'photo') || (filter === 'videos' && m.type === 'video'))
  return (
    <div className="flex flex-col">
      {/* Filter tabs */}
      <div className="flex border-b" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
        {(['todos', 'fotos', 'videos'] as const).map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className="flex-1 py-3 text-sm font-500 capitalize transition-all relative"
            style={{ color: filter === f ? '#F0EDEA' : '#6B6866' }}>
            {f.charAt(0).toUpperCase() + f.slice(1)}
            {filter === f && <span className="absolute bottom-0 left-0 right-0 h-0.5" style={{ backgroundColor: '#B3241F' }} />}
          </button>
        ))}
      </div>
      {/* Grid */}
      <div className="grid grid-cols-3 gap-px" style={{ backgroundColor: 'rgba(255,255,255,0.08)' }}>
        {filtered.map(item => (
          <div key={item.id} className="relative aspect-square overflow-hidden" style={{ backgroundColor: '#111' }}>
            <img src={item.url} alt="" className="w-full h-full object-cover" />
            {item.type === 'video' && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ backgroundColor: 'rgba(0,0,0,0.55)' }}>
                  <Icon.Live />
                </div>
                {item.duration && (
                  <span className="absolute bottom-1.5 right-1.5 text-xs font-600 px-1 rounded" style={{ backgroundColor: 'rgba(0,0,0,0.7)', color: '#fff' }}>
                    {item.duration}
                  </span>
                )}
              </div>
            )}
            <div className="absolute bottom-0 left-0 right-0 px-1.5 py-1" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.7), transparent)' }}>
              <span className="flex items-center gap-0.5 text-xs" style={{ color: 'rgba(255,255,255,0.8)' }}>
                <Icon.Heart />
                {item.likes > 999 ? (item.likes / 1000).toFixed(1) + 'k' : item.likes}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function DocsTab() {
  const [open, setOpen] = useState<string | null>('objetivo')
  const sections = [
    {
      id: 'objetivo',
      title: '1. Objetivo do Aplicativo',
      content: `O Pro Surf é uma rede social mobile-first dedicada à comunidade de surfe, reunindo em uma única plataforma: feed social, notícias, e-commerce, condições meteorológicas, campeonatos ao vivo, conexões sociais e galeria de mídia.

Missão: conectar surfistas de todos os níveis ao redor do mundo através de conteúdo autêntico, dados em tempo real e comunidade.`
    },
    {
      id: 'psicologia',
      title: '2. Psicologia Aplicada (UX)',
      content: `• Efeito de familiaridade (Zajonc): a estrutura de feed segue padrões do Instagram/TikTok para reduzir a curva de aprendizado.

• Hierarquia de necessidades de Maslow: o app atende pertencimento (feed/amigos), estima (engajamento/likes) e autorrealização (treino, campeonatos).

• Dopamina e recompensa variável: o feed em scroll infinito com likes e notificações mantém o engajamento por antecipação de recompensa.

• Identidade social (Tajfel): a aba de amigos reforça o senso de pertencimento ao grupo surfe.

• Percepção de urgência: o indicador AO VIVO em vermelho (#B3241F) ativa atenção imediata sem criar ansiedade excessiva (uso pontual).`
    },
    {
      id: 'nielsen',
      title: '3. Heurísticas de Nielsen',
      content: `1. Visibilidade do status: badge AO VIVO, progress bar em campeonatos, indicadores de maré e tempo real.

2. Compatibilidade com o mundo real: terminologia náutica ("enchendo", "ft", "nós"), emojis contextuais, dados em unidades locais.

3. Controle do usuário: filtros por categoria (shop, mídia), seleção de spot no clima, likes reversíveis.

4. Consistência: paleta única (preto, off-white, vermelho), tipografia DM Sans em todo o app, iconografia stroke uniforme.

5. Prevenção de erros: ações destrutivas exigem confirmação; carrinho com toggle visual.

6. Reconhecimento vs. memorização: ícones com labels na barra inferior, categorias visíveis no shop.

7. Flexibilidade: busca universal em feed, shop e amigos.

8. Design minimalista: dark immersive — controles recuam, imagem prevalece. Sem elementos decorativos.

9. Recuperação de erros: mensagens claras, sugestões de spots alternativos no clima.

10. Ajuda e documentação: esta aba documenta todas as decisões de design.`
    },
    {
      id: 'bastien',
      title: '4. Critérios de Bastien & Scapin',
      content: `Guia (Guidance): navegação inferior persistente com ícones + labels; estados ativos claros.

Carga de trabalho (Workload): densidade calibrada — feed aberto, shop em grade 2×2, scoreboard simplificado.

Controle explícito: ações do usuário têm feedback imediato (like, carrinho, filtro de mídia).

Adaptabilidade: layout responsivo; spots de clima selecionáveis; filtros de categoria.

Gestão de erros: estados vazios e de carregamento planejados; inputs com validação inline.

Consistência: tokens de cor, espaçamento (múltiplos de 8px) e radii (0–4px) uniformes.

Significância dos códigos: vermelho exclusivo para ao vivo/ativo; verde para online/bom; âmbar para regular.

Compatibilidade: padrões mentais de apps de surfe e redes sociais já estabelecidos.`
    },
    {
      id: 'tokens',
      title: '5. Decisões de Design & Tokens',
      content: `Paleta:
• Background: #0A0A0B (near-black absoluto)
• Foreground: #F0EDEA (off-white quente)
• Muted: #6B6866 (labels, timestamps)
• Accent: #B3241F (live, ativo, primário)
• Verde: #4A9E6A (online, bom)
• Âmbar: #C48A2A (regular, aviso)

Tipografia:
• DM Sans 400/500/600/700
• Sem serifa condensada, sem all-caps em blocos

Espaçamento: base 8px, múltiplos de 8

Radii: 0px (imagens full-bleed), 4px (cards), 2px (badges)

Imagens: sempre full-bleed sem borda, scrim gradient para legibilidade de texto sobreposto

Navegação: bottom bar 64px com 7 abas, scroll horizontal quando necessário`
    },
    {
      id: 'acessibilidade',
      title: '6. Acessibilidade & Boas Práticas',
      content: `• Contraste mínimo AA: #F0EDEA sobre #0A0A0B = 17.3:1 ✓
• Contraste muted: #6B6866 sobre #0A0A0B = 4.6:1 ✓
• Accent: #B3241F sobre #0A0A0B = 5.2:1 ✓
• Touch targets: mínimo 44×44px em todos os botões
• Estados de foco visíveis para navegação por teclado
• Alt text em todas as imagens
• Scrollbars ocultas mas funcionais
• Suporte a safe-area insets (iOS/Android notch)`
    },
  ]
  return (
    <div className="flex flex-col px-4 py-4 gap-2">
      <div className="mb-2">
        <h2 className="text-lg font-700" style={{ color: '#F0EDEA' }}>Documentação</h2>
        <p className="text-sm mt-1" style={{ color: '#6B6866' }}>Objetivo, decisões de design e usabilidade do Pro Surf.</p>
      </div>
      {sections.map(s => (
        <div key={s.id} className="rounded overflow-hidden" style={{ backgroundColor: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
          <button onClick={() => setOpen(open === s.id ? null : s.id)}
            className="w-full flex items-center justify-between px-4 py-3 text-left transition-colors hover:bg-white/[0.03]">
            <span className="text-sm font-600" style={{ color: '#F0EDEA' }}>{s.title}</span>
            <span className="text-lg" style={{ color: '#6B6866', transform: open === s.id ? 'rotate(90deg)' : 'none', transition: 'transform 0.2s', display: 'inline-block' }}>›</span>
          </button>
          {open === s.id && (
            <div className="px-4 pb-4 border-t" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
              <p className="text-sm leading-relaxed mt-3 whitespace-pre-line" style={{ color: '#6B6866' }}>{s.content}</p>
            </div>
          )}
        </div>
      ))}
    </div>
  )
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('feed')

  const tabs: { id: Tab; label: string; icon: React.ReactNode; badge?: boolean }[] = [
    { id: 'feed',    label: 'Feed',    icon: <Icon.Home /> },
    { id: 'news',    label: 'Notícias', icon: <Icon.News /> },
    { id: 'shop',    label: 'Shop',    icon: <Icon.Shop /> },
    { id: 'weather', label: 'Clima',   icon: <Icon.Wave /> },
    { id: 'live',    label: 'Ao Vivo', icon: <Icon.Live />, badge: true },
    { id: 'friends', label: 'Amigos',  icon: <Icon.Friends /> },
    { id: 'media',   label: 'Mídia',   icon: <Icon.Camera /> },
    { id: 'docs',    label: 'Docs',    icon: <Icon.Docs /> },
  ]

  const tabTitles: Record<Tab, string> = {
    feed: 'Pro Surf',
    news: 'Notícias',
    shop: 'Shop',
    weather: 'Condições',
    live: 'Ao Vivo',
    friends: 'Amigos',
    media: 'Mídia',
    docs: 'Documentação',
  }

  return (
    <div className="flex flex-col h-full max-w-md mx-auto relative" style={{ backgroundColor: '#0A0A0B', color: '#F0EDEA' }}>
      {/* Top Bar */}
      <header className="flex items-center justify-between px-4 py-3 flex-shrink-0"
        style={{ backgroundColor: '#0A0A0B', borderBottom: '1px solid rgba(255,255,255,0.08)', zIndex: 20 }}>
        <div className="flex items-center gap-2">
          {activeTab === 'feed' ? (
            <span className="text-lg font-700 tracking-tight" style={{ color: '#F0EDEA' }}>
              Pro<span style={{ color: '#B3241F' }}>Surf</span>
            </span>
          ) : (
            <span className="text-base font-600" style={{ color: '#F0EDEA' }}>{tabTitles[activeTab]}</span>
          )}
        </div>
        <div className="flex items-center gap-3" style={{ color: '#6B6866' }}>
          {activeTab === 'feed' && <button className="hover:text-white transition-colors"><Icon.Search /></button>}
          <button className="hover:text-white transition-colors relative">
            <Icon.Bell />
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full" style={{ backgroundColor: '#B3241F' }} />
          </button>
          <button>
            <Avatar src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=60&h=60&fit=crop&auto=format" size={28} online />
          </button>
        </div>
      </header>

      {/* Live status strip */}
      {activeTab === 'feed' && (
        <div className="flex items-center gap-2 px-4 py-2 flex-shrink-0" style={{ backgroundColor: 'rgba(179,36,31,0.08)', borderBottom: '1px solid rgba(179,36,31,0.2)' }}>
          <LiveBadge />
          <span className="text-xs" style={{ color: '#F0EDEA' }}>Tahiti Pro: Semifinal em andamento</span>
          <button className="ml-auto text-xs font-500" style={{ color: '#B3241F' }}>Assistir →</button>
        </div>
      )}

      {/* Content */}
      <main className="flex-1 overflow-y-auto">
        {activeTab === 'feed'    && <FeedTab />}
        {activeTab === 'news'    && <NewsTab />}
        {activeTab === 'shop'    && <ShopTab />}
        {activeTab === 'weather' && <WeatherTab />}
        {activeTab === 'live'    && <LiveTab />}
        {activeTab === 'friends' && <FriendsTab />}
        {activeTab === 'media'   && <MediaTab />}
        {activeTab === 'docs'    && <DocsTab />}
      </main>

      {/* Bottom Navigation */}
      <nav className="flex-shrink-0 border-t overflow-x-auto" style={{ backgroundColor: '#0A0A0B', borderColor: 'rgba(255,255,255,0.08)' }}>
        <div className="flex min-w-max">
          {tabs.map(tab => {
            const active = activeTab === tab.id
            return (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className="flex flex-col items-center justify-center gap-0.5 py-2 px-3 relative transition-all min-w-[56px]"
                style={{ color: active ? '#F0EDEA' : '#6B6866' }}>
                <span className="relative">
                  {tab.icon}
                  {tab.badge && (
                    <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: '#B3241F' }} />
                  )}
                </span>
                <span className="text-[10px] font-500 whitespace-nowrap">{tab.label}</span>
                {active && <span className="absolute top-0 left-1/2 -translate-x-1/2 w-6 h-0.5" style={{ backgroundColor: '#B3241F' }} />}
              </button>
            )
          })}
        </div>
      </nav>
    </div>
  )
}
